
export interface DiaryEntry {
  id: string;
  pageNumber: number;
  date: string;
  content: string;
  songLinks: string[];
  curatedLinks?: string[]; 
  summary?: string;
  moodScore: number; 
  tags: string[];
  image?: string; 
  reactions?: string[]; 
  location?: {
    lat: number;
    lng: number;
    address?: string;
  };
}

export type ElementalTheme = 'EARTH' | 'WATER' | 'FIRE' | 'AIR' | 'ETHER';

export interface PersonalityInsight {
  trait: string;
  score: number;
  description: string;
}

export interface TagFrequency {
  tag: string;
  count: number;
}

export interface GrowthAnalytics {
  moodTrend: { date: string; score: number }[];
  topThemes: string[];
  personalityMatrix: PersonalityInsight[];
  tagDistribution: TagFrequency[];
  growthSummary: string;
  periodLabel?: string;
}

export enum AppView {
  ENTRIES = 'entries',
  WRITE = 'write',
  ANALYTICS = 'analytics',
  VOICE = 'voice',
  CHAT = 'chat'
}

export enum TimeRange {
  WEEKLY = 'Weekly',
  MONTHLY = 'Monthly',
  QUARTERLY = 'Quarterly',
  ANNUAL = 'Annual',
  ALL_TIME = 'All Time'
}
