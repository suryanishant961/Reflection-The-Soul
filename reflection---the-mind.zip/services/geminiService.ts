
import { GoogleGenAI, Type } from "@google/genai";
import { DiaryEntry, GrowthAnalytics } from "../types";

// Always use the named parameter for apiKey and rely on process.env.API_KEY directly.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateMindSummary = async (content: string): Promise<{ summary: string, moodScore: number, tags: string[] }> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this diary entry and provide a concise 'summary of the mind' (internal emotional state), a mood score from 1-10, and 3-5 relevant tags. 
    Entry: "${content}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          moodScore: { type: Type.NUMBER },
          tags: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["summary", "moodScore", "tags"]
      }
    }
  });

  return JSON.parse(response.text.trim());
};

export const translateOrTransliterate = async (content: string, targetLanguage: string, mode: 'translate' | 'transliterate'): Promise<string> => {
  const prompt = mode === 'translate' 
    ? `Translate the following diary entry into ${targetLanguage}. Maintain the emotional tone and poetic nature of the original text. Original: "${content}"`
    : `Transliterate the following phonetic English typing into the correct ${targetLanguage} script. For example, if it's Hindi and the input is "Namaste", output "नमस्ते". Content: "${content}"`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
  });

  return response.text.trim();
};

export const editImage = async (base64Image: string, prompt: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { inlineData: { data: base64Image.split(',')[1], mimeType: 'image/png' } },
        { text: prompt }
      ]
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image generated");
};

export const chatWithDiary = async (message: string, history: any[], entries: DiaryEntry[]): Promise<{ text: string, sources?: any[] }> => {
  const context = entries.map(e => `[Page ${e.pageNumber}, ${e.date}]: ${e.content}`).join('\n\n');
  const fullPrompt = `You are the user's AI Reflection Assistant. You have access to their private diary entries below.
  
Context:
${context}

User Question: ${message}

Use Google Search if the user asks about external events or current context. Provide a empathetic, insightful response.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: fullPrompt,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  return {
    text: response.text || "I'm reflecting on that...",
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks
  };
};

export const analyzeGrowth = async (entries: DiaryEntry[]): Promise<GrowthAnalytics> => {
  const entriesText = entries.map(e => `[${e.date}] (Mood: ${e.moodScore}): ${e.content}`).join('\n---\n');
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analyze these diary entries to track personal growth and personality over time. 
    Return a mood trend, top themes, personality matrix (Big Five), tag distribution, and growth summary.
    Entries:
    ${entriesText}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          moodTrend: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                date: { type: Type.STRING },
                score: { type: Type.NUMBER }
              }
            }
          },
          topThemes: { type: Type.ARRAY, items: { type: Type.STRING } },
          personalityMatrix: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                trait: { type: Type.STRING },
                score: { type: Type.NUMBER },
                description: { type: Type.STRING }
              }
            }
          },
          tagDistribution: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                tag: { type: Type.STRING },
                count: { type: Type.NUMBER }
              }
            }
          },
          growthSummary: { type: Type.STRING }
        },
        required: ["moodTrend", "topThemes", "personalityMatrix", "tagDistribution", "growthSummary"]
      }
    }
  });

  return JSON.parse(response.text.trim());
};
