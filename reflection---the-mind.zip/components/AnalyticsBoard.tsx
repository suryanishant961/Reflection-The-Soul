
import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, PieChart, Pie, Cell } from 'recharts';
import { GrowthAnalytics } from '../types';
import { Sparkles, TrendingUp, User, Brain, Tag, Activity, Calendar } from 'lucide-react';

interface AnalyticsBoardProps {
  data: GrowthAnalytics;
}

const COLORS = ['#6366f1', '#f43f5e', '#fbbf24', '#10b981', '#8b5cf6', '#ec4899'];

export const AnalyticsBoard: React.FC<AnalyticsBoardProps> = ({ data }) => {
  const radarData = useMemo(() => {
    return data.personalityMatrix.map(item => ({
      subject: item.trait,
      A: item.score,
      fullMark: 100,
    }));
  }, [data.personalityMatrix]);

  const pieData = useMemo(() => {
    return data.tagDistribution.slice(0, 6).map(item => ({
      name: item.tag,
      value: item.count
    }));
  }, [data.tagDistribution]);

  const isDark = document.documentElement.classList.contains('dark');

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-700 pb-20">
      <div className="bg-white dark:bg-stone-900 rounded-3xl shadow-xl p-8 border border-stone-200 dark:border-stone-800 transition-colors duration-300">
        <div className="flex items-center justify-between mb-8">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-3">
              <Sparkles className="text-indigo-500 w-8 h-8" />
              <h2 className="text-3xl font-serif text-stone-800 dark:text-stone-100">Mind Synthesis</h2>
            </div>
            {data.periodLabel && (
              <div className="flex items-center gap-2 text-stone-400 dark:text-stone-500 font-bold text-xs uppercase tracking-widest mt-2 ml-1">
                <Calendar className="w-3 h-3" /> {data.periodLabel} Insight Report
              </div>
            )}
          </div>
          <div className="hidden sm:flex items-center gap-2 bg-stone-50 dark:bg-stone-800 px-4 py-2 rounded-2xl border border-stone-100 dark:border-stone-700">
             <Activity className="w-4 h-4 text-indigo-400" />
             <span className="text-xs font-bold uppercase tracking-widest text-stone-400">Churning Analysis Active</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Emotional Area Chart */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-stone-700 dark:text-stone-300 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-500" />
              Emotional Resonance
            </h3>
            <div className="h-72 w-full bg-stone-50/50 dark:bg-stone-800/20 rounded-3xl p-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.moodTrend}>
                  <defs>
                    <linearGradient id="colorMood" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#292524" : "#f0f0f0"} />
                  <XAxis 
                    dataKey="date" 
                    tick={{fontSize: 10, fill: isDark ? '#78716c' : '#a8a29e'}} 
                    tickFormatter={(str) => new Date(str).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})}
                    stroke={isDark ? "#44403c" : "#e7e5e4"}
                  />
                  <YAxis domain={[0, 10]} hide />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: isDark ? '#1c1917' : '#ffffff', 
                      borderRadius: '16px',
                      border: 'none',
                      boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                      color: isDark ? '#f5f5f4' : '#1c1917'
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="score" 
                    stroke="#6366f1" 
                    strokeWidth={4} 
                    fillOpacity={1} 
                    fill="url(#colorMood)" 
                    animationDuration={2000}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Personality Landscape */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-stone-700 dark:text-stone-300 flex items-center gap-2">
              <Brain className="w-5 h-5 text-rose-500" />
              Personality Landscape
            </h3>
            <div className="h-72 w-full bg-stone-50/50 dark:bg-stone-800/20 rounded-3xl p-4">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                  <PolarGrid stroke={isDark ? "#292524" : "#e5e7eb"} />
                  <PolarAngleAxis dataKey="subject" tick={{fontSize: 11, fill: isDark ? '#a8a29e' : '#6b7280'}} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} hide />
                  <Radar
                    name="Personality"
                    dataKey="A"
                    stroke="#f43f5e"
                    fill="#f43f5e"
                    fillOpacity={0.4}
                    animationDuration={2000}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Growth Narrative */}
        <div className="lg:col-span-2 bg-gradient-to-br from-indigo-600 to-violet-700 dark:from-indigo-800 dark:to-violet-900 text-white rounded-3xl p-8 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-serif mb-6 flex items-center gap-2">
              <User className="w-6 h-6" />
              Churning Insights
            </h3>
            <p className="text-indigo-100 leading-relaxed text-lg italic font-light">
              "{data.growthSummary}"
            </p>
          </div>
          <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap gap-2">
            {data.topThemes.map((theme, i) => (
              <span key={i} className="px-3 py-1 bg-white/10 rounded-full text-xs font-bold uppercase tracking-widest">
                {theme}
              </span>
            ))}
          </div>
        </div>

        {/* Tag Distribution Donut */}
        <div className="bg-white dark:bg-stone-900 rounded-3xl shadow-xl p-8 border border-stone-200 dark:border-stone-800 transition-colors duration-300 space-y-6">
          <h3 className="text-sm font-bold text-stone-400 dark:text-stone-500 uppercase tracking-widest flex items-center gap-2">
            <Tag className="w-4 h-4" />
            Mind Archetypes
          </h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  animationDuration={1500}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ 
                    backgroundColor: isDark ? '#1c1917' : '#ffffff', 
                    borderRadius: '12px',
                    border: 'none',
                    fontSize: '12px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {pieData.map((item, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[i % COLORS.length]}} />
                <span className="text-[10px] font-bold text-stone-500 dark:text-stone-400 truncate uppercase">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
