
import React, { useState } from 'react';
import { DiaryEntry } from '../types';
import { Music, Calendar, Wand2, Loader2, Image as ImageIcon, Save, SmilePlus, Bookmark, Globe, X, ExternalLink, MapPin } from 'lucide-react';
import { editImage } from '../services/geminiService';

const MusicIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
);

interface DiaryPageProps {
  entry: DiaryEntry;
  onEntryUpdate?: (entry: DiaryEntry) => void;
}

const REACTION_SET = ['✨', '🙏', '🌿', '🕯️', '🌊', '🕉️'];

export const DiaryPage: React.FC<DiaryPageProps> = ({ entry, onEntryUpdate }) => {
  const [isEditingImage, setIsEditingImage] = useState(false);
  const [editPrompt, setEditPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);

  const handleEditImage = async () => {
    if (!editPrompt.trim() || !entry.image) return;
    setIsGenerating(true);
    try {
      const newImage = await editImage(entry.image, editPrompt);
      if (onEntryUpdate) {
        onEntryUpdate({ ...entry, image: newImage });
      }
      setEditPrompt('');
      setIsEditingImage(false);
    } catch (error) {
      alert("AI Alchemy failed.");
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleReaction = (emoji: string) => {
    if (!onEntryUpdate) return;
    const currentReactions = entry.reactions || [];
    const newReactions = currentReactions.includes(emoji)
      ? currentReactions.filter(r => r !== emoji)
      : [...currentReactions, emoji];
    onEntryUpdate({ ...entry, reactions: newReactions });
  };

  return (
    <div className="bg-white/5 dark:bg-black/20 backdrop-blur-sm rounded-3xl shadow-xl border border-white/10 p-8 md:p-12 mb-12 max-w-3xl mx-auto relative overflow-hidden group">
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-white/5 to-transparent pointer-events-none"></div>
      
      {/* Manifested Image */}
      {entry.image && (
        <div className="mb-10 group relative rounded-2xl overflow-hidden border border-white/5 shadow-2xl">
          <img src={entry.image} alt="Soul memory" className="w-full h-auto max-h-[400px] object-cover transition-all duration-1000 group-hover:scale-110" />
          <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
             <button onClick={() => setIsEditingImage(!isEditingImage)} className="bg-white/90 p-2 rounded-xl text-indigo-600 shadow-lg hover:scale-110 transition-all"><Wand2 className="w-5 h-5" /></button>
          </div>
          {isEditingImage && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-6">
              <div className="w-full max-w-sm bg-white dark:bg-stone-800 rounded-3xl p-6 shadow-2xl">
                <input type="text" placeholder="Refine this manifestation..." value={editPrompt} onChange={(e) => setEditPrompt(e.target.value)} className="w-full bg-stone-100 dark:bg-stone-900 p-3 rounded-xl border border-stone-200 dark:border-stone-700 text-sm mb-4 focus:outline-none" />
                <div className="flex gap-2">
                   <button onClick={() => setIsEditingImage(false)} className="flex-1 py-2 text-sm opacity-50">Cancel</button>
                   <button onClick={handleEditImage} disabled={isGenerating} className="flex-1 bg-indigo-600 text-white py-2 rounded-xl text-sm font-bold flex items-center justify-center gap-2">
                     {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Alchemy'}
                   </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Page Signature */}
      <div className="flex justify-between items-start mb-8 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center text-stone-400 text-xs font-bold mb-1 tracking-[0.2em] uppercase">
            <Calendar className="w-4 h-4 mr-2" />
            {new Date(entry.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <h2 className="text-3xl font-serif flex items-center gap-4">Page {entry.pageNumber} {entry.location && <span className="text-[10px] font-sans opacity-30 flex items-center gap-1 uppercase"><MapPin className="w-2 h-2" /> {entry.location.address}</span>}</h2>
        </div>
        <div className="bg-white/5 border border-white/10 px-4 py-2 rounded-full font-mono text-[10px] opacity-60">RESONANCE: {entry.moodScore}/10</div>
      </div>

      {/* Soul Script */}
      <div className="prose dark:prose-invert max-w-none mb-12 leading-relaxed text-lg italic font-serif opacity-90">
        {entry.content.split('\n').map((para, i) => <p key={i} className="mb-4">{para}</p>)}
      </div>

      <div className="mb-10 flex flex-wrap items-center gap-3">
        {(entry.reactions || []).map((emoji) => <button key={emoji} onClick={() => toggleReaction(emoji)} className="px-4 py-2 bg-white/5 rounded-full text-xl hover:scale-110 transition-all">{emoji}</button>)}
        <button onClick={() => setShowReactionPicker(!showReactionPicker)} className="p-2 opacity-30 hover:opacity-100 transition-opacity"><SmilePlus className="w-5 h-5" /></button>
        {showReactionPicker && (
          <div className="absolute bottom-20 left-12 glass p-2 rounded-2xl border border-white/10 flex gap-2 z-20 animate-in fade-in zoom-in">
            {REACTION_SET.map(emoji => <button key={emoji} onClick={() => { toggleReaction(emoji); setShowReactionPicker(false); }} className="w-10 h-10 flex items-center justify-center rounded-xl text-xl hover:bg-white/10">{emoji}</button>)}
          </div>
        )}
      </div>

      {/* The Essence Summary */}
      {entry.summary && (
        <div className="bg-white/5 p-8 rounded-3xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500/50"></div>
          <p className="text-stone-400 font-serif leading-relaxed italic text-lg">"{entry.summary}"</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {entry.tags.map(tag => <span key={tag} className="text-[9px] font-black uppercase tracking-widest opacity-30">#{tag}</span>)}
          </div>
        </div>
      )}
    </div>
  );
};
