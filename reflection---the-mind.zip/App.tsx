
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { DiaryEntry, AppView, GrowthAnalytics, TimeRange, ElementalTheme } from './types';
import { DiaryPage } from './components/DiaryPage';
import { AnalyticsBoard } from './components/AnalyticsBoard';
import { generateMindSummary, analyzeGrowth, chatWithDiary, translateOrTransliterate } from './services/geminiService';
import { Plus, Book, LineChart as ChartIcon, Loader2, Music, Save, Trash2, Search, X, Sun, Moon, Activity, Calendar as CalendarIcon, Download, ChevronDown, MessageSquare, Mic, MicOff, Image as ImageIcon, Tag, Send, ExternalLink, Camera, RefreshCw, Bookmark, Globe, MapPin, Languages, Sparkles, Wind, Droplets, Mountain, Flame, Circle } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, YAxis, Tooltip, AreaChart, Area } from 'recharts';

// Speech API fallback
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}
interface SpeechRecognition extends EventTarget {
  continuous: boolean; interimResults: boolean; lang: string;
  start(): void; stop(): void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: any) => void;
  onend: () => void;
}

const INDIAN_LANGUAGES = [
  "Hindi", "Bengali", "Telugu", "Marathi", "Tamil", "Urdu", "Gujarati", "Kannada", "Odia", "Malayalam", "Punjabi", "Assamese", "Sanskrit"
];

const App: React.FC = () => {
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [view, setView] = useState<AppView>(AppView.ENTRIES);
  const [element, setElement] = useState<ElementalTheme>(() => {
    return (localStorage.getItem('soul_element') as ElementalTheme) || 'ETHER';
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [analytics, setAnalytics] = useState<GrowthAnalytics | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedRange, setSelectedRange] = useState<TimeRange>(TimeRange.ALL_TIME);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('manthana_dark_mode') === 'true');

  const videoRef = useRef<HTMLVideoElement>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isDictating, setIsDictating] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'ai', text: string, sources?: any[] }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatting, setIsChatting] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const [newContent, setNewContent] = useState('');
  const [newDate, setNewDate] = useState(new Date().toISOString().split('T')[0]);
  const [songLinks, setSongLinks] = useState<string[]>([]);
  const [curatedLinks, setCuratedLinks] = useState<string[]>([]);
  const [imageInput, setImageInput] = useState<string | null>(null);
  const [location, setLocation] = useState<DiaryEntry['location']>(undefined);
  const [isGettingLocation, setIsGettingLocation] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("Hindi");
  const [isProcessingLanguage, setIsProcessingLanguage] = useState(false);

  // Theme Mapping
  const themeMap = {
    EARTH: {
      bg: isDarkMode ? 'bg-[#1c1917]' : 'bg-[#f5f5f4]',
      accent: 'text-[#4b3621] dark:text-[#a8a29e]',
      btn: 'bg-[#4b3621] hover:bg-[#3b2a1a] dark:bg-[#78716c] dark:hover:bg-[#a8a29e] text-white',
      border: 'border-[#4b3621]/20 dark:border-[#78716c]/20',
      icon: <Mountain className="w-5 h-5" />,
      label: 'Prithvi',
      primary: '#4b3621'
    },
    WATER: {
      bg: isDarkMode ? 'bg-[#0f172a]' : 'bg-[#f0f9ff]',
      accent: 'text-sky-600 dark:text-sky-400',
      btn: 'bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 text-white',
      border: 'border-sky-200 dark:border-sky-900',
      icon: <Droplets className="w-5 h-5" />,
      label: 'Jala',
      primary: '#0ea5e9'
    },
    FIRE: {
      bg: isDarkMode ? 'bg-[#180808]' : 'bg-[#fff7ed]',
      accent: 'text-orange-600 dark:text-orange-400',
      btn: 'bg-orange-600 hover:bg-orange-700 dark:bg-orange-500 text-white',
      border: 'border-orange-200 dark:border-orange-900',
      icon: <Flame className="w-5 h-5" />,
      label: 'Agni',
      primary: '#f97316'
    },
    AIR: {
      bg: isDarkMode ? 'bg-[#0a0a0a]' : 'bg-[#fafafa]',
      accent: 'text-stone-600 dark:text-stone-300',
      btn: 'bg-stone-800 dark:bg-stone-200 text-white dark:text-stone-900',
      border: 'border-stone-200 dark:border-stone-800',
      icon: <Wind className="w-5 h-5" />,
      label: 'Vayu',
      primary: '#78716c'
    },
    ETHER: {
      bg: isDarkMode ? 'bg-[#020617]' : 'bg-[#fdfcf8]',
      accent: 'text-indigo-600 dark:text-indigo-400',
      btn: 'bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 text-white',
      border: 'border-indigo-200 dark:border-indigo-900',
      icon: <Circle className="w-5 h-5" />,
      label: 'Akasha',
      primary: '#6366f1'
    }
  };

  const activeTheme = themeMap[element];

  useEffect(() => {
    localStorage.setItem('soul_element', element);
  }, [element]);

  useEffect(() => {
    if (chatEndRef.current) chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, chatOpen]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      recognition.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        setNewContent(prev => prev + (prev.length > 0 && !prev.endsWith(' ') ? ' ' : '') + transcript);
      };
      recognition.onerror = () => setIsDictating(false);
      recognitionRef.current = recognition;
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
    localStorage.setItem('manthana_dark_mode', String(isDarkMode));
  }, [isDarkMode]);

  useEffect(() => {
    const saved = localStorage.getItem('manthana_diary_entries');
    if (saved) setEntries(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('manthana_diary_entries', JSON.stringify(entries));
  }, [entries]);

  // FIX: Added scrollToEntry function to allow navigation to specific entries from the sidebar
  const scrollToEntry = (id: string) => {
    const element = document.getElementById(`entry-${id}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // FIX: Added getMoodColor to provide visual feedback based on the AI-calculated mood score
  const getMoodColor = (score: number) => {
    if (score >= 8) return 'bg-emerald-500';
    if (score >= 6) return 'bg-indigo-500';
    if (score >= 4) return 'bg-amber-500';
    return 'bg-rose-500';
  };

  // FIX: Added deleteEntry to allow users to remove unwanted diary pages
  const deleteEntry = (id: string) => {
    if (window.confirm("Are you sure you want to delete this memory?")) {
      setEntries(prev => prev.filter(e => e.id !== id));
    }
  };

  // FIX: Added handleSendChat to manage conversational interactions with the diary context
  const handleSendChat = async () => {
    if (!chatInput.trim() || isChatting) return;
    const userMsg = chatInput;
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsChatting(true);
    try {
      // Passes current chat state and entries to the Gemini reflection service
      const response = await chatWithDiary(userMsg, [], entries);
      setChatMessages(prev => [...prev, { role: 'ai', text: response.text, sources: response.sources }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { role: 'ai', text: "The reflection pool is clouded. Please try again." }]);
    } finally {
      setIsChatting(false);
    }
  };

  const handleLanguageProcess = async (mode: 'translate' | 'transliterate') => {
    if (!newContent.trim()) return;
    setIsProcessingLanguage(true);
    try {
      const result = await translateOrTransliterate(newContent, selectedLanguage, mode);
      setNewContent(result);
    } catch (error) {
      alert("Language processing failed.");
    } finally {
      setIsProcessingLanguage(false);
    }
  };

  const filteredEntries = useMemo(() => {
    return entries.filter(entry => {
      const matchesTag = activeTag ? entry.tags.includes(activeTag) : true;
      const matchesSearch = searchQuery.trim() === '' ? true : (
        entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
      );
      return matchesTag && matchesSearch;
    });
  }, [entries, searchQuery, activeTag]);

  const miniTrendData = useMemo(() => {
    return [...entries].slice(0, 10).reverse().map(e => ({ score: e.moodScore, date: new Date(e.date).toLocaleDateString() }));
  }, [entries]);

  const toggleDictation = () => {
    if (!recognitionRef.current) return alert("Speech recognition not supported.");
    if (isDictating) { recognitionRef.current.stop(); setIsDictating(false); }
    else { recognitionRef.current.start(); setIsDictating(true); }
  };

  const getCurrentLocation = () => {
    setIsGettingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, address: `${pos.coords.latitude.toFixed(2)}, ${pos.coords.longitude.toFixed(2)}` });
        setIsGettingLocation(false);
      },
      () => { alert("Location failed."); setIsGettingLocation(false); }
    );
  };

  const handleSaveEntry = async () => {
    if (!newContent.trim()) return;
    setIsSubmitting(true);
    try {
      const { summary, moodScore, tags } = await generateMindSummary(newContent);
      const newEntry: DiaryEntry = {
        id: Date.now().toString(),
        pageNumber: entries.length + 1,
        date: new Date(newDate).toISOString(),
        content: newContent,
        songLinks: [], curatedLinks: [],
        summary, moodScore, tags, reactions: [], location: location
      };
      setEntries([newEntry, ...entries]);
      setNewContent(''); setView(AppView.ENTRIES);
    } catch (error) {
      alert("Save failed.");
    } finally { setIsSubmitting(false); }
  };

  const runAnalysis = async (range: TimeRange = TimeRange.ALL_TIME) => {
    setIsAnalyzing(true); setView(AppView.ANALYTICS); setSelectedRange(range);
    try {
      const result = await analyzeGrowth(entries);
      result.periodLabel = range;
      setAnalytics(result);
    } catch (e) { alert("Analysis failed."); } finally { setIsAnalyzing(false); }
  };

  return (
    <div className={`min-h-screen transition-all duration-700 ${activeTheme.bg} ${isDarkMode ? 'text-stone-100' : 'text-stone-800'} pb-20 font-sans`}>
      <nav className={`sticky top-0 z-50 glass border-b ${activeTheme.border}`}>
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView(AppView.ENTRIES)}>
            <div className={`w-10 h-10 ${activeTheme.btn} rounded-lg flex items-center justify-center font-serif text-xl font-bold transition-all duration-500`}>S</div>
            <h1 className="text-2xl font-serif font-semibold tracking-tighter hidden sm:block uppercase">The Soul</h1>
          </div>
          <div className="flex items-center gap-4">
            {/* Element Switcher */}
            <div className="flex items-center bg-stone-200/50 dark:bg-stone-800/50 rounded-full p-1 border border-white/10">
              {(['EARTH', 'WATER', 'FIRE', 'AIR', 'ETHER'] as ElementalTheme[]).map(e => (
                <button
                  key={e}
                  onClick={() => setElement(e)}
                  className={`p-2 rounded-full transition-all duration-300 ${element === e ? activeTheme.btn : 'text-stone-400 hover:text-stone-600'}`}
                  title={themeMap[e].label}
                >
                  {themeMap[e].icon}
                </button>
              ))}
            </div>
            <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-2 text-stone-400 hover:text-stone-600">
              {isDarkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>
            <button onClick={() => setView(AppView.ENTRIES)} className={`p-2 ${view === AppView.ENTRIES ? activeTheme.accent : 'text-stone-400'}`}><Book className="w-6 h-6" /></button>
            <button onClick={() => runAnalysis()} className={`p-2 ${view === AppView.ANALYTICS ? activeTheme.accent : 'text-stone-400'}`}><ChartIcon className="w-6 h-6" /></button>
            <button onClick={() => setView(AppView.WRITE)} className={`${activeTheme.btn} px-6 py-2 rounded-full font-bold shadow-lg transition-all flex items-center gap-2`}><Plus className="w-5 h-5" /> <span className="hidden sm:inline">Manifest</span></button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 pt-12">
        {view === AppView.WRITE && (
          <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4">
            <div className={`bg-white dark:bg-stone-900/50 glass rounded-3xl shadow-2xl p-8 md:p-12 border ${activeTheme.border}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                <div>
                   <h2 className="text-4xl font-serif">Page {entries.length + 1}</h2>
                   <p className="text-stone-400 text-sm mt-1 uppercase tracking-widest">{activeTheme.label} Resonance</p>
                </div>
                <button onClick={getCurrentLocation} className={`text-xs font-bold flex items-center gap-1 ${location ? 'text-emerald-500' : 'text-stone-400'}`}><MapPin className="w-3 h-3" />{location ? location.address : 'Tag Sthala'}</button>
              </div>

              <div className="flex flex-wrap items-center gap-4 mb-6 p-4 glass rounded-2xl border border-white/10">
                <Languages className="w-4 h-4 text-stone-400" />
                <select value={selectedLanguage} onChange={(e) => setSelectedLanguage(e.target.value)} className="bg-transparent text-sm font-bold focus:outline-none">
                  {INDIAN_LANGUAGES.map(lang => <option key={lang} value={lang}>{lang}</option>)}
                </select>
                <div className="flex gap-2 ml-auto">
                  <button onClick={() => handleLanguageProcess('transliterate')} className="px-3 py-1.5 glass border border-white/10 rounded-lg text-[10px] font-black uppercase hover:text-indigo-400 transition-all">Phonetic Switch</button>
                  <button onClick={() => handleLanguageProcess('translate')} className={`${activeTheme.btn} px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all`}>Translate</button>
                </div>
              </div>
              
              <div className="relative mb-8">
                <textarea 
                  placeholder="The soul speaks in many tongues..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full h-80 bg-transparent p-6 rounded-2xl border border-white/10 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-serif text-xl leading-relaxed italic"
                />
                <button onClick={toggleDictation} className={`absolute right-4 bottom-4 w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all ${isDictating ? activeTheme.btn + ' animate-pulse' : 'glass text-stone-400 hover:text-indigo-500'}`}>
                  {isDictating ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                </button>
              </div>

              <div className="flex justify-between items-center">
                <button onClick={() => setView(AppView.ENTRIES)} className="text-stone-400 hover:text-stone-600">Discard</button>
                <button onClick={handleSaveEntry} disabled={isSubmitting || !newContent.trim()} className={`${activeTheme.btn} px-10 py-4 rounded-2xl font-bold shadow-xl flex items-center gap-3`}>
                  {isSubmitting ? <><Loader2 className="w-5 h-5 animate-spin" /> Resonating...</> : <><Save className="w-5 h-5" /> Seal Reality</>}
                </button>
              </div>
            </div>
          </div>
        )}

        {view === AppView.ENTRIES && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <aside className="hidden lg:block lg:col-span-3 sticky top-32 h-fit space-y-6">
              <div className="glass rounded-3xl p-6 border border-white/10">
                <h3 className="text-xs font-black uppercase tracking-widest text-stone-400 mb-6 flex items-center gap-2"><Book className="w-4 h-4" /> Index of Being</h3>
                <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                  {entries.map((e) => (
                    <button key={e.id} onClick={() => scrollToEntry(e.id)} className="w-full text-left flex items-center justify-between p-2 rounded-xl hover:bg-stone-50/10 transition-all">
                      <div className="flex flex-col"><span className="text-sm font-bold font-serif">Page {e.pageNumber}</span><span className="text-[10px] opacity-50">{new Date(e.date).toLocaleDateString()}</span></div>
                      <div className={`w-3 h-3 rounded-full ${getMoodColor(e.moodScore)}`} />
                    </button>
                  ))}
                </div>
              </div>
            </aside>

            <div className="lg:col-span-9 space-y-8">
              <div className="space-y-6 max-w-3xl mx-auto">
                <div className="relative group w-full">
                  <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                  <input type="text" placeholder="Search the soul's echoes..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full pl-14 pr-12 py-4 glass rounded-2xl border border-white/10 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 font-serif italic text-lg" />
                </div>
                {entries.length > 0 && (
                  <div className={`glass rounded-3xl p-6 border ${activeTheme.border} shadow-sm flex flex-col gap-4`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2"><Activity className="w-4 h-4 text-indigo-500" /><span className="text-[10px] font-bold opacity-50 uppercase tracking-widest">Life Force Resonance</span></div>
                      <div className="text-right text-lg font-serif font-bold">{entries[0]?.moodScore || 0}/10</div>
                    </div>
                    <div className="h-20 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={miniTrendData}>
                          <defs><linearGradient id="miniMoodGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={activeTheme.primary} stopOpacity={0.2}/><stop offset="95%" stopColor={activeTheme.primary} stopOpacity={0}/></linearGradient></defs>
                          <YAxis domain={[0, 10]} hide /><Tooltip contentStyle={{ fontSize: '10px', borderRadius: '8px' }} labelStyle={{ display: 'none' }} />
                          <Area type="monotone" dataKey="score" stroke={activeTheme.primary} strokeWidth={2} fill="url(#miniMoodGradient)" dot={{ r: 3, fill: activeTheme.primary }} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}
              </div>

              {entries.length === 0 ? (
                <div className="text-center py-40 glass rounded-3xl border-2 border-dashed border-white/10 max-w-3xl mx-auto">
                  <Circle className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <h3 className="text-2xl font-serif opacity-50">Empty Space. Await Manifestation.</h3>
                  <button onClick={() => setView(AppView.WRITE)} className="mt-6 font-bold underline underline-offset-4 decoration-indigo-500">Begin Existence</button>
                </div>
              ) : (
                <div className="space-y-12">
                  {filteredEntries.map((entry) => (
                    <div key={entry.id} id={`entry-${entry.id}`} className="relative group max-w-3xl mx-auto flex gap-4">
                      <div className={`w-1 rounded-full hidden sm:block ${getMoodColor(entry.moodScore)}`} />
                      <div className="flex-1">
                        <div className="absolute -right-4 top-1/2 -translate-y-1/2 p-2 glass text-rose-400 rounded-full opacity-0 group-hover:opacity-100 transition-all z-10">
                          <button onClick={() => deleteEntry(entry.id)}><Trash2 className="w-4 h-4" /></button>
                        </div>
                        <DiaryPage entry={entry} onEntryUpdate={(updated) => setEntries(entries.map(e => e.id === updated.id ? updated : e))} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {view === AppView.ANALYTICS && (
          <div className="animate-in fade-in slide-in-from-bottom-4">
             <div className="flex flex-wrap items-center justify-center gap-4 mb-10 max-w-2xl mx-auto">
              {[TimeRange.WEEKLY, TimeRange.MONTHLY, TimeRange.QUARTERLY, TimeRange.ANNUAL, TimeRange.ALL_TIME].map(range => (
                <button key={range} onClick={() => runAnalysis(range)} className={`px-6 py-3 rounded-2xl font-bold text-sm transition-all border shadow-sm ${selectedRange === range ? activeTheme.btn : 'glass text-stone-400 border-white/10'}`}>{range}</button>
              ))}
            </div>
            {isAnalyzing || !analytics ? <div className="flex flex-col items-center justify-center py-40"><Loader2 className="w-12 h-12 text-indigo-300 animate-spin mb-6" /><h3 className="text-xl font-serif text-stone-500">Synthesizing Growth...</h3></div> : <AnalyticsBoard data={analytics} />}
          </div>
        )}
      </main>

      <div className="fixed bottom-8 right-8 flex flex-col gap-4 z-50">
        <button onClick={() => setChatOpen(!chatOpen)} className={`w-14 h-14 ${activeTheme.btn} rounded-full shadow-2xl flex items-center justify-center hover:scale-110 relative transition-all duration-500`}>
          <MessageSquare className="w-6 h-6" />
        </button>
        <button onClick={() => setView(AppView.WRITE)} className={`w-14 h-14 ${activeTheme.btn} rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all duration-500`}>
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {chatOpen && (
        <div className="fixed inset-y-0 right-0 w-full sm:w-96 glass shadow-2xl border-l border-white/10 flex flex-col z-[60] animate-in slide-in-from-right duration-300">
          <div className="p-6 border-b border-white/10 flex items-center justify-between font-serif font-bold">Resonance Reflection <button onClick={() => setChatOpen(false)}><X className="w-5 h-5" /></button></div>
          <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
            {chatMessages.map((msg, i) => <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[85%] p-4 rounded-2xl text-sm ${msg.role === 'user' ? activeTheme.btn + ' rounded-tr-none' : 'glass rounded-tl-none'}`}>{msg.text}</div></div>)}
            {isChatting && <div className="flex justify-start"><div className="glass p-4 rounded-2xl flex gap-1"><div className="w-1.5 h-1.5 bg-indigo-300 animate-bounce" /><div className="w-1.5 h-1.5 bg-indigo-300 animate-bounce [animation-delay:0.2s]" /></div></div>}
            <div ref={chatEndRef} />
          </div>
          <div className="p-4"><div className="relative"><input type="text" placeholder="Deepen the reflection..." value={chatInput} onChange={(e) => setChatInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendChat()} className="w-full glass border border-white/10 rounded-full py-3 pl-5 pr-12 text-sm focus:outline-none" /><button onClick={handleSendChat} disabled={!chatInput.trim() || isChatting} className={`absolute right-2 top-1.5 w-9 h-9 ${activeTheme.btn} rounded-full flex items-center justify-center`}><Send className="w-4 h-4" /></button></div></div>
        </div>
      )}
    </div>
  );
};

export default App;
